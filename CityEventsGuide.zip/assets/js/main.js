
// main.js - shared logic and event data

// ---- Dark mode toggle (with localStorage) ----
(function () {
  const root = document.documentElement;
  const key = 'ce-theme';
  const saved = localStorage.getItem(key);
  if (saved) root.setAttribute('data-theme', saved);
  document.addEventListener('click', (e) => {
    if (e.target && e.target.id === 'darkToggle') {
      const current = root.getAttribute('data-theme') === 'dark' ? '' : 'dark';
      if (current) root.setAttribute('data-theme', current);
      else root.removeAttribute('data-theme');
      localStorage.setItem(key, current);
    }
  });
})();

// ---- Event data (sample) ----
const CE_EVENTS = [
  {
    id: "ev1",
    title: "City Jazz Night",
    date: "2025-11-05",
    time: "19:30",
    location: "City Theater, Downtown",
    category: "Music",
    img: "https://picsum.photos/seed/jazz/800/450",
    excerpt: "Live jazz bands and open jam stage.",
    description: "An evening of smooth and fusion jazz featuring local bands. Doors open at 19:00. Snacks & beverages available.",
    map_img: "https://maps.googleapis.com/maps/api/staticmap?center=Dubai&zoom=12&size=600x300&markers=color:red|Dubai",
  },
  {
    id: "ev2",
    title: "Marathon for All",
    date: "2025-11-12",
    time: "07:00",
    location: "Seaside Boulevard",
    category: "Sports",
    img: "https://picsum.photos/seed/marathon/800/450",
    excerpt: "5K/10K community run by the sea.",
    description: "Join our inclusive 5K and 10K races. Family-friendly with hydration points and first-aid stations throughout the course.",
    map_img: "https://picsum.photos/seed/map1/600/300",
  },
  {
    id: "ev3",
    title: "Makers & Artisans Fair",
    date: "2025-11-02",
    time: "10:00",
    location: "Old Market Square",
    category: "Culture",
    img: "https://picsum.photos/seed/market/800/450",
    excerpt: "Handmade crafts, food trucks, and live music.",
    description: "Discover local creators, from pottery and textiles to gourmet bites. Workshops every hour. Pets welcome.",
    map_img: "https://picsum.photos/seed/map2/600/300",
  },
  {
    id: "ev4",
    title: "Family Science Day",
    date: "2025-11-09",
    time: "11:00",
    location: "Discovery Museum",
    category: "Family",
    img: "https://picsum.photos/seed/science/800/450",
    excerpt: "Hands-on experiments for kids 6-12.",
    description: "Physics, chemistry, and robotics demos with lab safety guidance. Free entry for kids under 8.",
    map_img: "https://picsum.photos/seed/map3/600/300",
  },
  {
    id: "ev5",
    title: "Indie Films Weekend",
    date: "2025-11-15",
    time: "18:00",
    location: "Riverside Cinema",
    category: "Culture",
    img: "https://picsum.photos/seed/film/800/450",
    excerpt: "Short films and director Q&A sessions.",
    description: "A curation of indie masterpieces from regional filmmakers. Vote for the Audience Award!",
    map_img: "https://picsum.photos/seed/map4/600/300",
  }
];

// ---- Helpers ----
function byId(id) { return document.getElementById(id); }
function qs(sel, parent=document) { return parent.querySelector(sel); }
function qsa(sel, parent=document) { return Array.from(parent.querySelectorAll(sel)); }

function formatDate(iso) {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString(undefined, { year:'numeric', month:'short', day:'numeric' });
}

// Render cards
function renderEvents(list, container) {
  container.innerHTML = '';
  if (!list.length) {
    container.innerHTML = `<div class="alert alert-warning">No events match your filters.</div>`;
    return;
  }
  const frag = document.createDocumentFragment();
  list.forEach(e => {
    const col = document.createElement('div');
    col.className = 'col';
    col.innerHTML = `
      <div class="card h-100 event-card position-relative">
        <span class="badge text-bg-secondary card-category">${e.category}</span>
        <img class="card-img-top" src="${e.img}" alt="${e.title}">
        <div class="card-body d-flex flex-column">
          <h5 class="card-title">${e.title}</h5>
          <p class="card-text small text-muted mb-2"><i class="bi bi-calendar2-event"></i> ${formatDate(e.date)} &middot; ${e.location}</p>
          <p class="card-text">${e.excerpt}</p>
          <div class="mt-auto">
            <a class="btn btn-primary w-100" href="event.html?id=${encodeURIComponent(e.id)}">Details</a>
          </div>
        </div>
      </div>`;
    frag.appendChild(col);
  });
  container.appendChild(frag);
}

// Filter logic
function applyFilters() {
  const term = (byId('searchTerm')?.value || '').toLowerCase().trim();
  const cat = byId('filterCategory')?.value || '';
  const when = byId('filterDate')?.value || '';
  let list = CE_EVENTS.slice();

  if (term) {
    list = list.filter(e => (e.title + ' ' + e.location + ' ' + e.excerpt + ' ' + e.category).toLowerCase().includes(term));
  }
  if (cat) {
    list = list.filter(e => e.category === cat);
  }
  if (when) {
    const today = new Date(); today.setHours(0,0,0,0);
    if (when === 'today') {
      list = list.filter(e => new Date(e.date).toDateString() === today.toDateString());
    } else if (when === 'week') {
      const week = new Date(today); week.setDate(today.getDate()+7);
      list = list.filter(e => new Date(e.date) >= today && new Date(e.date) <= week);
    } else if (when === 'month') {
      const month = new Date(today); month.setMonth(today.getMonth()+1);
      list = list.filter(e => new Date(e.date) >= today && new Date(e.date) <= month);
    }
  }
  const out = byId('eventsContainer');
  if (out) renderEvents(list, out);
}

// Single event page loader
function loadEventPage() {
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  const evt = CE_EVENTS.find(e => e.id === id) || CE_EVENTS[0];
  if (!evt) return;

  const titleEl = byId('evTitle');
  const metaEl  = byId('evMeta');
  const imgEl   = byId('evImg');
  const descEl  = byId('evDesc');
  const mapEl   = byId('evMap');
  const related = byId('relatedEvents');

  titleEl.textContent = evt.title;
  metaEl.textContent = `${formatDate(evt.date)} • ${evt.time} • ${evt.location}`;
  imgEl.src = evt.img;
  imgEl.alt = evt.title;
  descEl.textContent = evt.description;
  mapEl.src = evt.map_img;

  // Related events (same category, excluding self)
  const rel = CE_EVENTS.filter(e => e.category === evt.category && e.id !== evt.id).slice(0,3);
  if (rel.length) renderEvents(rel, related);

  // Add to calendar
  const ics = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//City Events Guide//EN',
    'BEGIN:VEVENT',
    `UID:${evt.id}@cityevents`,
    `DTSTAMP:${new Date().toISOString().replace(/[-:]/g,'').split('.')[0]}Z`,
    `DTSTART:${evt.date.replace(/-/g,'')}T${(evt.time||'18:00').replace(':','')}00Z`,
    `SUMMARY:${evt.title}`,
    `LOCATION:${evt.location}`,
    `DESCRIPTION:${evt.description}`,
    'END:VEVENT',
    'END:VCALENDAR'
  ].join('\r\n');

  const addBtn = byId('addToCal');
  const dataUri = 'data:text/calendar;charset=utf8,' + encodeURIComponent(ics);
  addBtn.setAttribute('href', dataUri);
  addBtn.setAttribute('download', `${evt.title.replace(/\s+/g,'_')}.ics`);

  // Share button
  const shareBtn = byId('shareBtn');
  shareBtn.addEventListener('click', async () => {
    const url = location.href;
    try {
      if (navigator.share) {
        await navigator.share({ title: evt.title, text: evt.excerpt, url });
      } else {
        await navigator.clipboard.writeText(url);
        alert('Link copied to clipboard');
      }
    } catch (_) {}
  });
}

// Contact form validation
function initContact() {
  const form = byId('contactForm');
  const alertBox = byId('contactAlert');
  if (!form) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    alertBox.innerHTML = '';
    const name = byId('name').value.trim();
    const email = byId('email').value.trim();
    const message = byId('message').value.trim();
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

    if (!name || !emailOk || !message) {
      alertBox.innerHTML = `<div class="alert alert-danger" role="alert">Please fill all required fields with a valid email.</div>`;
      return;
    }
    alertBox.innerHTML = `<div class="alert alert-success" role="alert">Your message has been sent successfully. Thank you!</div>`;
    form.reset();
  });
}

// Index page carousel population
function initIndex() {
  const featured = CE_EVENTS.slice(0, 3);
  const wrap = byId('featuredSlides');
  if (!wrap) return;
  featured.forEach((e, i) => {
    const item = document.createElement('div');
    item.className = `carousel-item ${i===0 ? 'active':''}`;
    item.innerHTML = `
      <img src="${e.img}" class="d-block w-100" alt="${e.title}" style="max-height:420px;object-fit:cover;">
      <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-3">
        <h5>${e.title}</h5>
        <p>${e.excerpt}</p>
        <a href="event.html?id=${encodeURIComponent(e.id)}" class="btn btn-primary">View details</a>
      </div>`;
    wrap.appendChild(item);
  });
}

// Events page init
function initEventsPage() {
  const container = byId('eventsContainer');
  if (!container) return;
  renderEvents(CE_EVENTS, container);
  document.addEventListener('input', (e) => {
    if (['searchTerm','filterCategory','filterDate'].includes(e.target.id)) applyFilters();
  });
  // quick category badges
  qsa('[data-cat]').forEach(b => b.addEventListener('click', () => {
    const v = b.getAttribute('data-cat');
    const sel = byId('filterCategory');
    sel.value = v;
    applyFilters();
  }));
}

// Page router
document.addEventListener('DOMContentLoaded', () => {
  if (byId('featuredSlides')) initIndex();
  if (byId('eventsContainer')) initEventsPage();
  if (byId('evTitle')) loadEventPage();
  if (byId('contactForm')) initContact();
});
